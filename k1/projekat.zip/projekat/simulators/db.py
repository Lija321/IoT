class SimulatedBuzzer:
    def on(self):
        print("[SIM] Buzzer ON")

    def off(self):
        print("[SIM] Buzzer OFF")
