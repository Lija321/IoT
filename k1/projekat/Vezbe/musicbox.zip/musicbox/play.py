import RPi.GPIO as GPIO
import time
import argparse
from notes import notes, load_song


GPIO.setmode(GPIO.BCM)


def setup_active(buzzer_pin):
    GPIO.setup(buzzer_pin, GPIO.OUT)

def setup_passive(buzzer_pin):
    GPIO.setup(buzzer_pin, GPIO.OUT)
    Buzz = GPIO.PWM(buzzer_pin, 440) # inital frequency
    return Buzz



def buzz_active(pitch, duration, buzzer_pin):
    period = 1.0/pitch
    delay = period/2.0
    cycles = int(duration * pitch)

    for _ in range(cycles):
        GPIO.output(buzzer_pin, GPIO.HIGH)
        time.sleep(delay)
        GPIO.output(buzzer_pin, GPIO.LOW)
        time.sleep(delay)


def buzz_passive(pitch, duration, Buzz):
    Buzz.ChangeFrequency(pitch) # frequency
    Buzz.start(50) # duty cycle
    time.sleep(duration)
    Buzz.stop()


def play_active(buzzer_pin, song, duration=1, pause=1):
    for note in song:
        buzz_active(notes[note['note']], note['duration'] * duration, buzzer_pin)
        time.sleep(note['duration'] * duration*pause)

def play_passive(Buzz, song, duration=1, pause=1):
    for note in song:
        buzz_passive(notes[note['note']], note['duration'] * duration, Buzz)
        time.sleep(note['duration'] * duration*pause)

def getArgs():

    argParser = argparse.ArgumentParser()
    argParser.add_argument('-b', '--buzzer', default='active', choices=['active', 'passive'])
    argParser.add_argument('-f', '--file', required=True)
    argParser.add_argument('-d', '--duration', default=0.5, type=float)
    argParser.add_argument('-p', '--pause', default=1, type=float)
    argParser.add_argument('-bp', '--buzzer_pin', required=True,type=int)

    args = argParser.parse_args()
    
    return args

def main():
    args = getArgs()
    print('Playing: ', args.file)
    song = load_song(args.file)

    try:
        if args.buzzer[0] == 'active':
            setup_active(args.buzzer_pin)
            play_active(args.buzzer_pin, song, duration=args.duration, pause=args.pause)
        else:
            Buzz = setup_passive(args.buzzer_pin)
            play_passive(Buzz, song, duration=args.duration, pause=args.pause)
    except KeyboardInterrupt:
        GPIO.cleanup()

    print('Performance over')
    
main()